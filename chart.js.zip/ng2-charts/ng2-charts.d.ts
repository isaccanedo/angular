/**
 * Generated bundle index. Do not edit.
 */
export * from './public_api';

//# sourceMappingURL=ng2-charts.d.ts.map