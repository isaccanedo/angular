/**
 * @fileoverview added by tsickle
 * Generated from: ng2-charts.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Generated bundle index. Do not edit.
 */
export { ChartsModule, BaseChartDirective, defaultColors, ThemeService, monkeyPatchChartJsLegend, monkeyPatchChartJsTooltip } from './public_api';
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmcyLWNoYXJ0cy5qcyIsInNvdXJjZXMiOlsiLi4vLi4vLi4vcHJvamVjdHMvbmcyLWNoYXJ0cy9zcmMvbmcyLWNoYXJ0cy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFJQSxBQUFBLEFBQUEsQUFBQSIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogR2VuZXJhdGVkIGJ1bmRsZSBpbmRleC4gRG8gbm90IGVkaXQuXG4gKi9cblxuZXhwb3J0ICogZnJvbSAnLi9wdWJsaWNfYXBpJztcbiJdfQ==