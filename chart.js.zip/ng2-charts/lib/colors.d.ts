import { Color } from './color';
export interface Colors extends Color {
    data?: number[];
    label?: string;
}
