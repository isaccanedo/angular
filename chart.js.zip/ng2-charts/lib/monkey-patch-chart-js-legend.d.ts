export declare function monkeyPatchChartJsLegend(): void;
