import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './base-chart.directive';
export declare class ChartsModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<ChartsModule, [typeof ɵngcc1.BaseChartDirective], never, [typeof ɵngcc1.BaseChartDirective]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<ChartsModule>;
}

//# sourceMappingURL=charts.module.d.ts.map