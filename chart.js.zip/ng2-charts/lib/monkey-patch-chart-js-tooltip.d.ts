export declare function monkeyPatchChartJsTooltip(): void;
