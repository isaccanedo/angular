export declare const defaultColors: Array<number[]>;
